import Order from "../models/Order.js";

export const createOrder = async (req, res) => {
  try {
    const { userId, items, total } = req.body;
    const order = new Order({ user: userId, items, total });
    await order.save();
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getOrders = async (req, res) => {
  try {
    const orders = await Order.find().populate("user", "username");
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
